# config.py
BAIDU_APP_ID = "117747355"
BAIDU_API_KEY = "CTeU8kxApZQ1RQSesKE8zKq6"
BAIDU_SECRET_KEY = "BHXqCW5u8dkv9Obvs64m0yUQqKmXbpdh"
BAIDU_ENDPOINT = "https://aip.baidubce.com/rest/26/ai/v1/online-speech-recognition"
