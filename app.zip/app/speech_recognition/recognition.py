#_*_ coding:UTF-8 _*_
# @author: zdl 
# .......Demo..............
# ....python-SDK.........60s......wav...
# ........ ... .....16K PCM.. .............

# ..AipSpeech  AipSpeech......Python SDK...
from aip import AipSpeech
import os

''' ..APPID AK SK  ...................'''
APP_ID = '117747355'
API_KEY = 'CTeU8kxApZQ1RQSesKE8zKq6'
SECRET_KEY = 'BHXqCW5u8dkv9Obvs64m0yUQqKmXbpdh'

# ....AipSpeech
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)


# ....
def get_file_content(test):   #filePath  ......
    with open(test, 'rb') as fp:
        return fp.read()

        
def stt(test):         # ....
    # ......
    result = client.asr(get_file_content(test),
                        'wav',
                        16000
                        #,
                        #{'dev_pid': 1536,}      # dev_pid........... 1536.....
                        )
    print (result)


    # ...............
    if result['err_msg']=='success.':
        word = result['result'][0].encode('utf-8')       # utf-8..
        if word!='':
            if word[len(word)-3:len(word)]=='.':
                print (word[0:len(word)-3])
                with open('demo.txt','wb+') as f:
                    f.write(word[0:len(word)-3])
                f.close()
            else:
                print (word.decode('utf-8').encode('gbk'))
                with open('demo.txt','wb+') as f:
                    f.write(word)
                f.close()
        else:
            print ("............")
    else:
        print ("..")

# main.. ........yahboom.wav
if __name__ == '__main__':
    
    stt('test.wav')


