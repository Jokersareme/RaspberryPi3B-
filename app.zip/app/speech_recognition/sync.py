#_*_ coding:UTF-8 _*_
# @author: zdl 
# .......Demo..............
# ....python-SDK.........1024...
# ......audio.mp3 ........

# ..AipSpeech  AipSpeech......Python SDK...
from aip import AipSpeech
import os

''' ..APPID AK SK  ...................'''
APP_ID = ''6497658
API_KEY = 'CTeU8kxApZQ1RQSesKE8zKq6'
SECRET_KEY = 'BHXqCW5u8dkv9Obvs64m0yUQqKmXbpdh'

# ....AipSpeech
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

# ...........
def tts(demo):
    f = open(demo,'r')
    command = f.read()
    if len(command) != 0:
        word = command
    f.close()
    result  = client.synthesis(word,'zh',1, {
        'vol': 5,'per':0,
    })
    
# ......audio.mp3......dict 
    if not isinstance(result, dict):
        with open('audio.mp3', 'wb') as f:
            f.write(result)
        f.close()
        print ('tts successful')

# main

if __name__ == '__main__':

tts('demo.txt')


