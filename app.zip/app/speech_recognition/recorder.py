# speech_recorder.py
import os
import time
import sys

# from scipy.special import result

# from pydub import AudioSegment
from aip import AipSpeech
from pyaudio import PyAudio, paInt16

BAIDU_APP_ID = "117747355"
BAIDU_API_KEY = "CTeU8kxApZQ1RQSesKE8zKq6"
BAIDU_SECRET_KEY = "BHXqCW5u8dkv9Obvs64m0yUQqKmXbpdh"
BAIDU_ENDPOINT = "https://aip.baidubce.com/rest/26/ai/v1/online-speech-recognition"

#close warning and error
#os.close(sys.stderr.fileno())

global devices

def init_baidu_sdk():
    """INITIAL BAIDU AI SDK"""
    return AipSpeech(BAIDU_APP_ID, BAIDU_API_KEY, BAIDU_SECRET_KEY)

p=PyAudio()
devices=p.get_device_count()

with open("runlog", "w") as de:
    log=[]
    for i in range(p.get_device_count()):
#    print(p.get_device_info_by_index(i))#.get('max_input_channels', 0))
        log.append(p.get_device_info_by_index(i))
    for j in range(len(log)):
#        print(log[j])
        for key,val in log[j].items():
            de.write(f'{key}: {val}\n')

# Iterate through all devices
def find_microphone_device(p):
    device_list = []
    for i in range(devices):
       # Get the device info
       device_info = p.get_device_info_by_index(i)
       # Check if this device is a microphone (an input device)
       if device_info.get('maxInputChannels') > 0 and device_info.get('hostApi') == 0:
          # device_list.append(f"Microphone: {device_info.get('name')} , Device Index: {device_info.get('index')}")
          device_list.append(device_info.get('index'))
          #print(f"Microphone: {device_info.get('name')} , Device Index: {device_info.get('index')}")
          print("microphone is selected by id = " + str(i))
          return i

#
# def find_microphone_device(p):
#     """Auto find microphone"""
#     for i in range(p.get_device_count()):
#         if p.get_device_info_by_index(i).get('max_input_channels', 0) > 0:
#             return i
#     raise RuntimeError("Microphone not found")

# find_microphone_device(p)

def record_audio(device_index, duration=5):
    """Record speech"""
    stream = p.open(
        format=paInt16,
        channels=1,
        rate=16000,
        input=True,
        input_device_index=device_index,
        frames_per_buffer=1024
    )

    frames = []
    start_time = time.time()
    print("Starting recording...")

    while time.time() - start_time < duration:
        data = stream.read(1024)
        frames.append(data)

    stream.stop_stream()
    stream.close()
    p.terminate()

    with open("record.wav", "wb") as f:
        f.write(b''.join(frames))
    print("Record finish. The file is saved as record.wav")

# device_index = find_microphone_device(p)
# record_audio(device_index, duration=5)

def speech_to_text(audio_file):
    
    print("Starting converting...")
    

    aip_speech = init_baidu_sdk()

    aip_speech.setConnectionTimeoutInMillis(10000) 

    with open(audio_file, "rb") as f:
        audio_data = f.read()

    result = aip_speech.asr(audio_data)

    print("The result has been converted! Now writting it in result_all.txt")

    with open("result_all.txt", "w") as fr:
        fr.write(f"{result}")

    print("File result_all has been saved, return result!")
    return result['result'][-1]

if __name__ == "__main__":
    device_index = find_microphone_device(p)
    #devices=p.get_device_count()
    record_audio(device_index, duration=5)
    text = speech_to_text("record.wav")

    # text = speech_to_text("test.wav")

    # Recognition and Save

    with open("result.txt", "w", encoding="utf-8") as f:


        f.write(f"Recognition result:\n{text}")
    print(f"Recognition has been saved in result.txt")
