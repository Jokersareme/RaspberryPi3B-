from detector import detect  # detect.py

model='Xiaogao.pmdl'

detect(model)
