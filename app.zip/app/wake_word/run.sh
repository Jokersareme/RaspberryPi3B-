python3 begin_detect.py Xiaogao.pmdl
